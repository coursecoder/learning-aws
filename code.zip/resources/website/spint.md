> Remove this file from universal once done

# Sprint

```bash
live-server --port=9090
```



## Now



## Later

- [ ] do nice looking item effect
  - [ ] possibly higher res images
  - [ ] consider filter or masks
  - [ ] what is interactive
  - [ ] on offer and new tags?
  - [ ] more descriptions
  - [ ] fig caption possible mask
  - [ ] filter top sub header for browsing
  - [ ] Need loading items placeholder
  - [ ] Need pagination, and item count

Desktop view vs mobile view

About us???

​	Images to use?

